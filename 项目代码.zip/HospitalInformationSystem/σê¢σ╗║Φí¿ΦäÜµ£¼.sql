-- 用户信息表
CREATE TABLE UserInfo (
    UserID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(50) NOT NULL COMMENT '用户的名字',
    Gender CHAR(1) COMMENT '性别：0男1女2未知3不详', 
    DateOfBirth DATE COMMENT '生日', 
    IDNumber VARCHAR(255) COMMENT '身份证号', 
    Address VARCHAR(255) COMMENT '地址', 
    PhoneNumber VARCHAR(20) COMMENT '联系电话', 
    Email VARCHAR(100) UNIQUE NOT NULL COMMENT '邮箱', 
    RoleID CHAR(2) COMMENT '角色ID 0超级管理员，1管理员，2医生，3患者', 
    CreateTime DATETIME NOT NULL COMMENT '创建日期', 
    CreateOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    UpdaterTime DATETIME NOT NULL COMMENT '修改日期', 
    UpdaterOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    IsActive CHAR(1) DEFAULT '1' COMMENT '是否禁用：1启用有效0禁用'
);

-- 登录表
CREATE TABLE Login (
    UserID INT COMMENT '用户ID与UserInfo表UserID关联',
    Username VARCHAR(50) PRIMARY KEY NOT NULL UNIQUE COMMENT '用户名，患者为就诊卡号,医生为工号',
    Password VARCHAR(255) DEFAULT '111111' NOT NULL COMMENT '密码：初始密码111111',
    LastLogin DATETIME COMMENT '最后登录时间',
    CreateTime DATETIME NOT NULL COMMENT '创建日期', 
    CreateOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    UpdaterTime DATETIME NOT NULL COMMENT '修改日期', 
    UpdaterOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    IsActive CHAR(1) DEFAULT '1' COMMENT '是否禁用：1启用有效0禁用'
);

-- 医生排班表
CREATE TABLE DoctorSchedule (
    ScheduleID INT AUTO_INCREMENT PRIMARY KEY,
    DoctorID INT NOT NULL COMMENT '医生ID',
    ScheduleDate DATE NOT NULL COMMENT '排班日期',
    StartTime TIME NOT NULL COMMENT '开始时间',
    EndTime TIME NOT NULL COMMENT '结束时间',
    MaxAppointmentCount int COMMENT '最大预约数',
    Department VARCHAR(100) NOT NULL COMMENT '科室',
    CreateTime DATETIME NOT NULL COMMENT '创建日期', 
    CreateOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    UpdaterTime DATETIME NOT NULL COMMENT '修改日期', 
    UpdaterOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    IsActive CHAR(1) DEFAULT '1' COMMENT '是否禁用：1启用有效0禁用'
);

-- 医生预约表
CREATE TABLE DoctorAppointment (
    AppointmentID INT AUTO_INCREMENT PRIMARY KEY,
    ScheduleID int COMMENT '医生排班表',
    PatientID INT NOT NULL COMMENT '患者ID',
    DoctorID INT NOT NULL COMMENT '医生ID',
    AppointmentDate DATE NOT NULL COMMENT '预约日期',
    AppointmentTime TIME NOT NULL COMMENT '预约时间',
    Status ENUM('待确认', '已确认', '已取消') NOT NULL DEFAULT '待确认' COMMENT '预约状态',
    Notes TEXT COMMENT '备注',
    CreateTime DATETIME NOT NULL COMMENT '创建日期', 
    CreateOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    UpdaterTime DATETIME NOT NULL COMMENT '修改日期', 
    UpdaterOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    IsActive CHAR(1) DEFAULT '1' COMMENT '是否禁用：1启用有效0禁用'
);

-- 就诊表
CREATE TABLE MedicalVisit (
    VisitID INT AUTO_INCREMENT PRIMARY KEY,
    AppointmentID INT NOT NULL COMMENT '预约ID',
    PatientID INT NOT NULL COMMENT '患者ID',
    DoctorID INT NOT NULL COMMENT '医生ID',
    VisitDate DATE NOT NULL COMMENT '就诊日期',
    VisitTime TIME NOT NULL COMMENT '就诊时间',
    Status ENUM('未登记','已登记', '就诊', '取消','完诊') NOT NULL DEFAULT '未登记' COMMENT '预约状态',
    DiagnosisID VARCHAR(100) COMMENT '诊断',
    CreateTime DATETIME NOT NULL COMMENT '创建日期', 
    CreateOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    UpdaterTime DATETIME NOT NULL COMMENT '修改日期', 
    UpdaterOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    IsActive CHAR(1) DEFAULT '1' COMMENT '是否禁用：1启用有效0禁用'
);

-- 处方表
CREATE TABLE Prescription (
    PrescriptionID INT AUTO_INCREMENT PRIMARY KEY,
    VisitID INT NOT NULL COMMENT '就诊ID',
    DoctorID INT NOT NULL COMMENT '医生ID',
    PatientID INT NOT NULL COMMENT '患者ID',
    PrescriptionDate DATE NOT NULL COMMENT '开具日期',
    Frequency VARCHAR(200) COMMENT '频次',
    Route VARCHAR(50) NOT NULL COMMENT '用法途径',
    Medications VARCHAR(200) COMMENT '药品信息',
    Dosage NUMERIC(10,2) COMMENT '用药剂量',
    Unit ENUM('瓶', '盒', '片') COMMENT '总量单位',
    PerUnit NUMERIC(10,2) COMMENT '每次用药剂量',
    DosagePerUse  ENUM('毫升', '片') COMMENT '每次用药单位',
    Notes TEXT COMMENT '备注',
    CreateTime DATETIME NOT NULL COMMENT '创建日期', 
    CreateOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    UpdaterTime DATETIME NOT NULL COMMENT '修改日期', 
    UpdaterOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    IsActive CHAR(1) DEFAULT '1' COMMENT '是否禁用：1启用有效0禁用'
);
-- 病历表
CREATE TABLE MedicalRecord (
    RecordID INT AUTO_INCREMENT PRIMARY KEY,
    VisitID INT NOT NULL COMMENT '就诊ID',
    PatientID INT NOT NULL COMMENT '患者ID', -- 关联患者信息
    DoctorID INT NOT NULL COMMENT '医生ID', -- 关联医生信息
    Diagnosis TEXT COMMENT '诊断信息',
    TreatmentPlan TEXT COMMENT '病历信息',
    CreateTime DATETIME NOT NULL COMMENT '创建日期', 
    CreateOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    UpdaterTime DATETIME NOT NULL COMMENT '修改日期', 
    UpdaterOperator VARCHAR(50) NOT NULL COMMENT '操作员',
    IsActive CHAR(1) DEFAULT '1' COMMENT '是否禁用：1启用有效0禁用'
);

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalInformationSystemFrom
{
    public class returnMessage
    {
        public bool isSucceed { get; set; }
        public string errorManger { get; set; }
    }
}
